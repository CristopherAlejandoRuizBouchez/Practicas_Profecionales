import pandas as pd

columnas_a_eliminar = ['timestamp', 'home_team_goal_timings', 'away_team_goal_timings',
                       'average_goals_per_match_pre_match', 'btts_percentage_pre_match',
                       'over_15_percentage_pre_match', 'over_25_percentage_pre_match',
                       'over_35_percentage_pre_match', 'over_45_percentage_pre_match',
                       'over_15_HT_FHG_percentage_pre_match']

def eliminar_columnas(df, columnas_a_eliminar):
    df_nuevo = df.drop(columnas_a_eliminar, axis=1)
    return df_nuevo

archivo_csv = 'premier-league-2018-2019.csv'
df = pd.read_csv(archivo_csv)

mi_df_sin_columnas = eliminar_columnas(df, columnas_a_eliminar)

print("DataFrame original:")
print(df)

print("\nDataFrame sin las columnas especificadas:")
print(mi_df_sin_columnas)

nuevo_archivo_csv = 'premier-league-2018-2019_sin_columnas.csv'
mi_df_sin_columnas.to_csv(nuevo_archivo_csv, index=False)
print(f"\nNuevo DataFrame guardado en '{nuevo_archivo_csv}'.")

